package parsers;

import model.DueDate;
import model.Priority;
import model.Status;
import model.Task;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// Represents Task parser
public class TaskParser {

    // EFFECTS: iterates over every JSONObject in the JSONArray represented by the input
    // string and parses it as a task; each parsed task is added to the list of tasks.
    // Any task that cannot be parsed due to malformed JSON data is not added to the
    // list of tasks.
    // Note: input is a string representation of a JSONArray
    public List<Task> parse(String input) {
        List<Task> taskList = new ArrayList<>();
        JSONArray taskArray = new JSONArray(input);
        for (Object object : taskArray) {
            JSONObject taskJson = (JSONObject) object;
            Task task = new Task("fodder");
            try {
                setTask(task, taskJson);
                taskList.add(task);
            } catch (JSONException e) {
                continue;
            }
        }
        return taskList;
    }

    private void setTask(Task task, JSONObject taskJson) {
        String description = taskJson.getString("description");
        JSONObject priority = taskJson.getJSONObject("priority");
        String status = taskJson.getString("status");
        JSONArray tags = taskJson.getJSONArray("tags");
        task.setDescription(description);
        setPriority(task, priority);
        if (taskJson.has("due-date")) {
            if (!taskJson.isNull("due-date")) {
                setDueDate(task, taskJson.getJSONObject("due-date"));
            } else {
                task.setDueDate(null);
            }
        } else {
            throw new JSONException("Invalid due-date");
        }
        setStatus(task, status);
        setTags(task,tags);
    }

    private void setTags(Task task, JSONArray tags) {
        for (Object o : tags) {
            JSONObject t = (JSONObject) o;
            String name = t.getString("name");
            task.addTag(name);
        }
    }

    private void setStatus(Task task, String status) {
        if (status.equals("TODO")) {
            task.setStatus(Status.TODO);
        } else if (status.equals("IN_PROGRESS")) {
            task.setStatus(Status.IN_PROGRESS);
        } else if (status.equals("DONE")) {
            task.setStatus(Status.DONE);
        } else if (status.equals("UP_NEXT")) {
            task.setStatus(Status.UP_NEXT);
        } else {
            throw new JSONException("Invalid status");
        }
    }

    private void setDueDate(Task task, JSONObject dueDate) {
        int year = dueDate.getInt("year");
        int month = dueDate.getInt("month");
        int day = dueDate.getInt("day");
        int hour = dueDate.getInt("hour");
        int minute = dueDate.getInt("minute");
        DueDate d = new DueDate();
        Date date = new Date();
        date.setMinutes(minute);
        date.setHours(hour);
        date.setDate(day);
        date.setMonth(month);
        date.setYear(year - 1900);
        d.setDueDate(date);
        task.setDueDate(d);
    }

    private void setPriority(Task task, JSONObject priority) {
        Boolean urgent = priority.getBoolean("urgent");
        Boolean important = priority.getBoolean("important");
        Priority p = new Priority();
        p.setUrgent(urgent);
        p.setImportant(important);
        task.setPriority(p);
    }
}
