package persistence;


import model.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

// Converts model elements to JSON objects
public class Jsonifier {

    // EFFECTS: returns JSON representation of tag
    public static JSONObject tagToJson(Tag tag) {
        JSONObject tagJson = new JSONObject();
        tagJson.put("name", tag.getName());
        return tagJson;
    }

    // EFFECTS: returns JSON representation of priority
    public static JSONObject priorityToJson(Priority priority) {
        JSONObject priorityJson = new JSONObject();
        priorityJson.put("urgent", priority.isUrgent());
        priorityJson.put("important", priority.isImportant());
        return priorityJson;
    }

    // EFFECTS: returns JSON representation of dueDate
    public static JSONObject dueDateToJson(DueDate dueDate) {
        if (dueDate == null) {
            return null;
        }
        JSONObject dueDateJson = new JSONObject();
        dueDateJson.put("minute", dueDate.getDate().getMinutes());
        dueDateJson.put("hour", dueDate.getDate().getHours());
        dueDateJson.put("day", dueDate.getDate().getDate());
        dueDateJson.put("month", dueDate.getDate().getMonth());
        dueDateJson.put("year", dueDate.getDate().getYear() + 1900);
        return dueDateJson;
    }

    // EFFECTS: returns JSON representation of task
    public static JSONObject taskToJson(Task task) {
        JSONObject taskJson = new JSONObject();
        taskJson.put("status", getStatus(task));
        taskJson.put("priority", priorityToJson(task.getPriority()));
        if (dueDateToJson(task.getDueDate()) == null) {
            taskJson.put("due-date", JSONObject.NULL);
        } else {
            taskJson.put("due-date", dueDateToJson(task.getDueDate()));
        }
        JSONArray tagsArray = new JSONArray();
        for (Tag t : task.getTags()) {
            tagsArray.put(tagToJson(t));
        }
        taskJson.put("tags", tagsArray);
        taskJson.put("description", task.getDescription());
        return taskJson;
    }

    private static String getStatus(Task task) {
        if (task.getStatus() == Status.TODO) {
            return "TODO";
        } else if (task.getStatus() == Status.IN_PROGRESS) {
            return "IN_PROGRESS";
        } else if (task.getStatus() == Status.DONE) {
            return "DONE";
        } else {
            return "UP_NEXT";
        }
    }

    // EFFECTS: returns JSON array representing list of tasks
    public static JSONArray taskListToJson(List<Task> tasks) {
        JSONArray tasksArray = new JSONArray();
        for (Task t : tasks) {
            tasksArray.put(taskToJson(t));
        }
        return tasksArray;
    }
}
