package utility;

import jdk.nashorn.internal.parser.JSONParser;
import jdk.nashorn.internal.parser.Parser;
import model.Task;
import org.json.JSONArray;
import parsers.TaskParser;
import persistence.Jsonifier;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

// File input/output operations
public class JsonFileIO {
    public static final File jsonDataFile = new File("./resources/json/tasks.json");
    
    // EFFECTS: attempts to read jsonDataFile and parse it
    //           returns a list of tasks from the content of jsonDataFile
    public static List<Task> read() {
        TaskParser parser = new TaskParser();
        List<Task> taskList = new ArrayList<>();
        try {
            String text = new String(Files.readAllBytes(Paths.get(jsonDataFile.toURI())), StandardCharsets.UTF_8);
            taskList = parser.parse(text);
        } catch (IOException e) {
            System.out.println("Reading error");
        }
        return taskList; // stub
    }
    
    // EFFECTS: saves the tasks to jsonDataFile
    public static void write(List<Task> tasks) {
        Jsonifier jsonifier = new Jsonifier();
        JSONArray jsonArray = jsonifier.taskListToJson(tasks);
        try (FileWriter file = new FileWriter(jsonDataFile)) {
            file.write(jsonArray.toString());
            file.flush();
        } catch (IOException e) {
            System.out.println("write error");
        }
    }
}
