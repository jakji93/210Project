package model;

import model.exceptions.EmptyStringException;
import model.exceptions.NullArgumentException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TestProject {
    private Project project1;

    @BeforeEach
    public void runBefore() {
        project1 = new Project("Test1");
    }

    @Test
    void testConstructor() {
        assertEquals("Test1", project1.getDescription());
        assertEquals(0, project1.getNumberOfTasks());
        assertEquals(0, project1.getProgress());
        assertEquals(0, project1.getEstimatedTimeToComplete());
    }

    @Test
    void testConstructorThrowEmptyStringException() {
        try {
            project1 = new Project("");
            fail("Failed to throw EmptyStringException");
        } catch (EmptyStringException e) {
            //nothing to do here
        }
    }

    @Test
    void testConstructorThrowEmptyStringException2() {
        try {
            project1 = new Project(null);
            fail("Failed to throw EmptyStringException");
        } catch (EmptyStringException e) {
            //nothing to do here
        }
    }

    @Test
    void testAdd() {
        Task task1 = null;
        task1 = new Task("test1");
        project1.add(task1);
        assertEquals(1, project1.getNumberOfTasks());
    }

    @Test
    void testAddTaskAndProject() {
        Task task1 = null;
        task1 = new Task("test1");
        Project project2 = new Project("test2");
        project1.add(task1);
        project1.add(project2);
        assertEquals(2, project1.getNumberOfTasks());
    }

    @Test
    void testAddSameProject() {
        project1.add(project1);
        assertEquals(0, project1.getNumberOfTasks());
    }

    @Test
    void testAddProject() {
        Project project2 = new Project("test2");
        project1.add(project2);
        assertEquals(1, project1.getNumberOfTasks());
    }

    @Test
    void testAddThrowNullArgumentException() {
        try {
            project1.add(null);
            fail("Failed to throw NullArgumentException");
        } catch (NullArgumentException e) {
            //nothing happens
        }
        assertEquals(0, project1.getNumberOfTasks());
    }

    @Test
    void testAddSame() {
        Task task1 = new Task("test1");
        Task task2 = new Task("test1");
        project1.add(task1);
        project1.add(task2);
        assertEquals(1, project1.getNumberOfTasks());
    }

    @Test
    void testAddMulti() {
        Task task1 = null;
        task1 = new Task("test1");
        Task task2 = new Task("test2");
        project1.add(task1);
        project1.add(task2);
        assertEquals(2, project1.getNumberOfTasks());
    }

    @Test
    void testRemoveEmptyList() {
        project1.remove(new Task("test"));
        assertEquals(0, project1.getNumberOfTasks());
    }

    @Test
    void testRemoveTask() {
        Task task1 = null;
        task1 = new Task("test");
        project1.add(task1);
        project1.remove(task1);
        assertEquals(0, project1.getNumberOfTasks());
    }

    @Test
    void testRemoveThrowNullArgumentException() {
        try {
            project1.remove(null);
            fail("Failed to throw NullArgumentException");
        } catch (NullArgumentException e) {
            //nothing happens
        }
        assertEquals(0, project1.getNumberOfTasks());
    }

    @Test
    void testRemoveNonExistTask() {
        Task task1 = new Task("test1");
        project1.add(task1);
        project1.remove(new Task("test2"));
        assertEquals(1, project1.getNumberOfTasks());
    }

    @Test
    void testRemove2ndTask() {
        Task task1 = null;
        task1 = new Task("test1");
        Task task2 = new Task("test2");
        project1.add(task1);
        project1.add(task2);
        project1.remove(task2);
        assertEquals(1, project1.getNumberOfTasks());
        assertTrue(project1.contains(task1));
    }

    @Test
    void testRemove1stTask() {
        Task task1 = null;
        task1 = new Task("test1");
        Task task2 = new Task("test2");
        project1.add(task1);
        project1.add(task2);
        project1.remove(task1);
        assertEquals(1, project1.getNumberOfTasks());
        assertTrue(project1.contains(task2));
    }

    @Test
    void testGetProgressEmpty() {
        assertEquals(0, project1.getProgress());
    }

    @Test
    void testGetProgress0() {
        Task task1 = new Task("test1");
        Task task2 = new Task("test2");
        Task task3 = new Task("test3");
        project1.add(task1);
        project1.add(task2);
        project1.add(task3);
        assertEquals(0, project1.getProgress());
    }

    @Test
    void testGetProgress33() {
        Task task1 = new Task("test1");
        Task task2 = new Task("test2");
        Task task3 = new Task("test3");
        task1.setProgress(100);
        project1.add(task1);
        project1.add(task2);
        project1.add(task3);
        assertEquals(33, project1.getProgress());
    }

    @Test
    void testGetProgress58() {
        Task task1 = new Task("test1");
        Task task2 = new Task("test2");
        Task task3 = new Task("test3");
        task1.setProgress(100);
        task2.setProgress(50);
        task3.setProgress(25);
        project1.add(task1);
        project1.add(task2);
        project1.add(task3);
        assertEquals(58, project1.getProgress());
    }

    @Test
    void testGetProgress29() {
        Task task1 = new Task("test1");
        Task task2 = new Task("test2");
        Task task3 = new Task("test3");
        task1.setProgress(100);
        task2.setProgress(50);
        task3.setProgress(25);
        Project project2 = new Project("test2");
        Task task4 = new Task("test4");
        project2.add(task4);
        project1.add(task1);
        project1.add(task2);
        project1.add(task3);
        project2.add(project1);
        assertEquals(29, project2.getProgress());
    }

    @Test
    void testIsCompleteEmpty() {
        assertFalse(project1.isCompleted());
    }

    @Test
    void testIsCompleteTrue() {
        Task task1 = null;
        task1 = new Task("test1");
        task1.setProgress(100);
        project1.add(task1);
        assertTrue(project1.isCompleted());
    }

    @Test
    void testIsCompleteFalse() {
        Task task1 = null;
        task1 = new Task("test1");
        project1.add(task1);
        assertFalse(project1.isCompleted());
    }

    @Test
    void testContainsEmpty() {
        assertFalse(project1.contains(new Task("test")));
    }

    @Test
    void testContainsTrue() {
        Task task1 = null;
        task1 = new Task("test1");
        project1.add(task1);
        assertTrue(project1.contains(new Task("test1")));
    }

    @Test
    void testContainsThrowNullArgumentException() {
        Task task1 = null;
        task1 = new Task("test1");
        project1.add(task1);
        try {
            assertTrue(project1.contains(null));
            fail("Failed to throw NullArgumentException");
        } catch (NullArgumentException e) {
            //nothing happens
        }
    }

    @Test
    void testContainsFalse() {
        Task task1 = null;
        task1 = new Task("test1");
        project1.add(task1);
        assertFalse(project1.contains(new Task("test2")));
    }

    @Test
    void testGetEstimatedTimeToComplete() {
        assertEquals(0, project1.getEstimatedTimeToComplete());
    }

    @Test
    void testGetEstimatedTimeToComplete0() {
        Task task1 = new Task("test1");
        Task task2 = new Task("test2");
        Task task3 = new Task("test3");
        project1.add(task1);
        project1.add(task2);
        project1.add(task3);
        assertEquals(0, project1.getEstimatedTimeToComplete());
    }

    @Test
    void testGetEstimatedTimeToComplete8() {
        Task task1 = new Task("test1");
        Task task2 = new Task("test2");
        Task task3 = new Task("test3");
        task1.setEstimatedTimeToComplete(8);
        project1.add(task1);
        project1.add(task2);
        project1.add(task3);
        assertEquals(8, project1.getEstimatedTimeToComplete());
    }

    @Test
    void testGetEstimatedTimeToComplete20() {
        Task task1 = new Task("test1");
        Task task2 = new Task("test2");
        Task task3 = new Task("test3");
        task1.setEstimatedTimeToComplete(8);
        task2.setEstimatedTimeToComplete(10);
        task3.setEstimatedTimeToComplete(2);
        project1.add(task1);
        project1.add(task2);
        project1.add(task3);
        assertEquals(20, project1.getEstimatedTimeToComplete());
    }

    @Test
    void testGetEstimatedTimeToComplete24() {
        Task task1 = new Task("test1");
        Task task2 = new Task("test2");
        Task task3 = new Task("test3");
        Task task4 = new Task("test4");
        Project project2 = new Project("test2");
        task1.setEstimatedTimeToComplete(8);
        task2.setEstimatedTimeToComplete(10);
        task3.setEstimatedTimeToComplete(2);
        task4.setEstimatedTimeToComplete(4);
        project1.add(task1);
        project1.add(task2);
        project1.add(task3);
        project2.add(task4);
        project2.add(project1);
        assertEquals(24, project2.getEstimatedTimeToComplete());
    }

    @Test
    void testProjectIterator() {
        Task task1 = new Task("test1");
        Task task2 = new Task("test2");
        Task task3 = new Task("test3");
        Task task4 = new Task("test4");
        task1.setPriority(new Priority(1));
        task2.setPriority(new Priority(2));
        task3.setPriority(new Priority(3));
        task4.setPriority(new Priority(4));
        project1.add(task4);
        project1.add(task3);
        project1.add(task2);
        project1.add(task1);
        for (Todo t : project1) {
            System.out.println(t.getDescription());
        }
    }

    @Test
    void testProjectIterator2() {
        Task task1 = new Task("test1");
        Task task2 = new Task("test2");
        Task task3 = new Task("test3");
        Task task4 = new Task("test4");
        task1.setPriority(new Priority(1));
        task2.setPriority(new Priority(2));
        task3.setPriority(new Priority(2));
        task4.setPriority(new Priority(2));
        project1.add(task4);
        project1.add(task3);
        project1.add(task2);
        project1.add(task1);
        for (Todo t : project1) {
            System.out.println(t.getDescription());
        }
    }
}