package model;

import model.exceptions.EmptyStringException;
import model.exceptions.InvalidProgressException;
import model.exceptions.NegativeInputException;
import model.exceptions.NullArgumentException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class TestTask {
    private Task task1;

    @BeforeEach
    public void runBefore() {
        task1 = new Task("Test1");
    }

    @Test
    void testConstructor() {
        Priority priority = new Priority();
        Status status = Status.TODO;
        assertEquals("Test1", task1.getDescription());
        assertEquals(priority.toString(), task1.getPriority().toString());
        assertEquals(status, task1.getStatus());
        assertNull(task1.getDueDate());
        assertTrue(task1.getTags().isEmpty());
        assertEquals(0, task1.getProgress());
        assertEquals(0, task1.getEstimatedTimeToComplete());
    }

    @Test
    void testConstructorThrowEmptyStringException() {
        try {
            task1 = new Task("");
            fail("Failed to throw EmptyStringException");
        } catch (EmptyStringException e) {
            //nothing to do here
        }
    }

    @Test
    void testConstructorThrowEmptyStringException2() {
        try {
            task1 = new Task(null);
            fail("Failed to throw EmptyStringException");
        } catch (EmptyStringException e) {
            //nothing to do here
        }
    }

    @Test
    void testAddNewTag() {
        task1.addTag("test");
        assertEquals(1, task1.getTags().size());
    }

    @Test
    void testAddNewTagThrowEmptyStringException() {
        try {
            task1.addTag("");
            fail("Failed to throw EmptyStringException");
        } catch (EmptyStringException e) {
            //nothing to do here
        }
        assertEquals(0, task1.getTags().size());
    }

    @Test
    void testAddNewTagThrowEmptyStringException2() {
        try {
            String str = null;
            task1.addTag(str);
            fail("Failed to throw EmptyStringException");
        } catch (EmptyStringException e) {
            //nothing to do here
        }
        assertEquals(0, task1.getTags().size());
    }

    @Test
    void testAddSameTag() {
        task1.addTag("test");
        task1.addTag("test");
        assertEquals(1, task1.getTags().size());
    }

    @Test
    void testRemoveTag() {
        task1.addTag("test");
        task1.removeTag("test");
        assertEquals(0, task1.getTags().size());
    }

    @Test
    void testRemoveTagThrowEmptyStringException() {
        task1.addTag("test");
        try {
            task1.removeTag("");
            fail("Failed to throw EmptyStringException");
        } catch (EmptyStringException e) {
            //nothing to do here
        }
        assertEquals(1, task1.getTags().size());
    }

    @Test
    void testRemoveTagThrowEmptyStringException2() {
        task1.addTag("test");
        try {
            String str = null;
            task1.removeTag(str);
            fail("Failed to throw EmptyStringException");
        } catch (EmptyStringException e) {
            //nothing to do here
        }
        assertEquals(1, task1.getTags().size());
    }

    @Test
    void testRemoveEmptyTags() {
        task1.removeTag("test");
        assertEquals(0, task1.getTags().size());
    }

    @Test
    void testRemoveNonExistTag() {
        task1.addTag("test");
        task1.removeTag("t");
        assertEquals(1, task1.getTags().size());
    }

    @Test
    void testSetPriority() {
        task1.setPriority(new Priority(1));
        assertEquals(new Priority(1).toString(), task1.getPriority().toString());
    }

    @Test
    void testSetPriorityThrowNullArgumentException() {
        try {
            task1.setPriority(null);
            fail("Failed to throw NullArgumentException");
        } catch (NullArgumentException e) {
            //nothing happens
        }
        assertEquals(new Priority().toString(), task1.getPriority().toString());
    }

    @Test
    void testSetStatus() {
        task1.setStatus(Status.DONE);
        assertEquals(Status.DONE.toString(), task1.getStatus().toString());
    }

    @Test
    void testSetStatusThrowNullArgumentException() {
        try {
            task1.setStatus(null);
            fail("Failed to throw NullArgumentException");
        } catch (NullArgumentException e) {
            //nothing happens
        }
        assertEquals(Status.TODO.toString(), task1.getStatus().toString());
    }

    @Test
    void testSetDescription() {
//        try {
            task1.setDescription("Test2");
//        } catch (ParsingException e) {
//            fail("Caught unexpected Parsing Exception");
//        }
        assertEquals("Test2", task1.getDescription());
    }

    @Test
    void testSetDescriptionThrowEmptyStringException() {
        try {
            task1.setDescription("");
            fail("Failed to throw EmptyStringException");
        } catch (EmptyStringException e) {
            //nothing happens
        }
        assertEquals("Test1", task1.getDescription());
    }

    @Test
    void testSetDescriptionThrowEmptyStringException2() {
        try {
            task1.setDescription(null);
            fail("Failed to throw EmptyStringException");
        } catch (EmptyStringException e) {
            //nothing happens
        }
        assertEquals("Test1", task1.getDescription());
    }

    @Test
    void testSetDueDate() {
        task1.setDueDate(new DueDate());
        assertEquals(new DueDate().toString(), task1.getDueDate().toString());
    }

    @Test
    void testContainTagTrue() {
        task1.addTag("test");
        assertTrue(task1.containsTag("test"));
    }

    @Test
    void testContainTagFalse() {
        task1.addTag("test");
        assertFalse(task1.containsTag("t"));
    }

    @Test
    void testToString() {
        task1.addTag("test1");
        String s = "\n" + "{" + "\n" + "\tDescription: Test1" + "\n" + "\tDue date: " + "\n" + "\tStatus: TODO" + "\n" + "\tPriority: DEFAULT" + "\n" + "\tTags: #test1" + "\n" + "}";
        assertEquals(s, task1.toString());
    }

    @Test
    void testToString2() {
        task1.addTag("test1");
        task1.setDueDate(new DueDate(new Date(119, 1, 3)));
        String s = "\n" + "{" + "\n" + "\tDescription: Test1" + "\n" + "\tDue date: Sun Feb 03 2019 12:00 AM" + "\n" + "\tStatus: TODO" + "\n" + "\tPriority: DEFAULT" + "\n" + "\tTags: #test1" + "\n" + "}";
        assertEquals(s, task1.toString());
    }

    @Test
    void testToString3() {
        task1.addTag("test2");
        task1.addTag("test1");
        String s = "\n" + "{" + "\n" + "\tDescription: Test1" + "\n" + "\tDue date: " + "\n" + "\tStatus: TODO" + "\n" + "\tPriority: DEFAULT" + "\n" + "\tTags: #test1, #test2" + "\n" + "}";
        assertEquals(s, task1.toString());
    }

    @Test
    void testSetProgress() {
        task1.setProgress(50);
        assertEquals(50, task1.getProgress());
    }

    @Test
    void testSetProgressThrowException1() {
        try {
            task1.setProgress(-1);
            fail("Fail to throw InvalidProgressException");
        } catch (InvalidProgressException e) {
            //expected
        }
    }

    @Test
    void testSetProgressThrowException2() {
        try {
            task1.setProgress(101);
            fail("Fail to throw InvalidProgressException");
        } catch (InvalidProgressException e) {
            //expected
        }
    }

    @Test
    void testSetEstimatedTimeToComplete() {
        task1.setEstimatedTimeToComplete(1);
        assertEquals(1, task1.getEstimatedTimeToComplete());
    }

    @Test
    void testSetEstimatedTimeToCompleteThrowException() {
        try {
            task1.setEstimatedTimeToComplete(-1);
            fail("Fail to throw NegativeInputException");
        } catch (NegativeInputException e) {
            //expected
        }
    }
}